# Pack de skills AI Makers — Finance & RevOps

Votre récompense du Benchmark des Makers : 3 skills d'agent, choisies pour votre métier,
prêtes à installer dans Claude Code (ou tout agent compatible Agent Skills).

## Installation

Copiez chaque dossier dans `.claude/skills/` de votre projet (ou `~/.claude/skills/`
pour les avoir partout), puis relancez Claude Code. C'est tout.

## Contenu

- **sales-enablement/** — Matériel d'aide à la vente : argumentaires, objections, one-pagers.
- **excel-automation/** — Automatiser Excel : formules, tableaux croisés, nettoyage, rapports.
- **kpi-dashboard-design/** — Concevoir des dashboards KPI : choix des métriques, hiérarchie, lecture.

## Sources et licences

Ces skills sont open source ; leurs licences sont dans `LICENSES/`. Sélection AI Makers,
août 2026, depuis skills.sh :

- `coreyhaines31/marketingskills` (MIT) — github.com/coreyhaines31/marketingskills
- `claude-office-skills/skills` (MIT) — github.com/claude-office-skills/skills
- `wshobson/agents` (MIT) — github.com/wshobson/agents

---
aimakers.fr · Le Benchmark des Makers
