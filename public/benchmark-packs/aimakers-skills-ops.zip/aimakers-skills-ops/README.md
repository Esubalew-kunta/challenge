# Pack de skills AI Makers — Process & Ops

Votre récompense du Benchmark des Makers : 3 skills d'agent, choisies pour votre métier,
prêtes à installer dans Claude Code (ou tout agent compatible Agent Skills).

## Installation

Copiez chaque dossier dans `.claude/skills/` de votre projet (ou `~/.claude/skills/`
pour les avoir partout), puis relancez Claude Code. C'est tout.

## Contenu

- **n8n-workflow-patterns/** — Les patterns de workflows n8n qui tiennent en production.
- **n8n-error-handling-official/** — Gestion d'erreurs n8n (officiel) : retries, branches d'erreur, échecs silencieux.
- **n8n-workflow-lifecycle-official/** — Cycle de vie d'un workflow n8n (officiel) : construire, tester, déployer.

## Sources et licences

Ces skills sont open source ; leurs licences sont dans `LICENSES/`. Sélection AI Makers,
août 2026, depuis skills.sh :

- `czlonkowski/n8n-skills` (MIT) — github.com/czlonkowski/n8n-skills
- `n8n-io/skills` (Apache-2.0) — github.com/n8n-io/skills

---
aimakers.fr · Le Benchmark des Makers
