# Pack de skills AI Makers — Engineering & Tech

Votre récompense du Benchmark des Makers : 3 skills d'agent, choisies pour votre métier,
prêtes à installer dans Claude Code (ou tout agent compatible Agent Skills).

## Installation

Copiez chaque dossier dans `.claude/skills/` de votre projet (ou `~/.claude/skills/`
pour les avoir partout), puis relancez Claude Code. C'est tout.

## Contenu

- **improve-codebase-architecture/** — Plan d'amélioration d'architecture d'un codebase, par étapes vérifiables.
- **code-review/** — Revue de code structurée : correction, lisibilité, risques.
- **git-guardrails-claude-code/** — Garde-fous git pour Claude Code : éviter les commandes destructives et les pertes de travail.

## Sources et licences

Ces skills sont open source ; leurs licences sont dans `LICENSES/`. Sélection AI Makers,
août 2026, depuis skills.sh :

- `mattpocock/skills` (MIT) — github.com/mattpocock/skills

---
aimakers.fr · Le Benchmark des Makers
