# Pack de skills AI Makers — Marketing & Growth

Votre récompense du Benchmark des Makers : 3 skills d'agent, choisies pour votre métier,
prêtes à installer dans Claude Code (ou tout agent compatible Agent Skills).

## Installation

Copiez chaque dossier dans `.claude/skills/` de votre projet (ou `~/.claude/skills/`
pour les avoir partout), puis relancez Claude Code. C'est tout.

## Contenu

- **ai-seo/** — Être cité par ChatGPT, Perplexity et les AI Overviews : llms.txt, citabilité, optimisation pour les moteurs de réponse.
- **seo-audit/** — Audit SEO technique et on-page avec plan d'action priorisé.
- **content-strategy/** — Stratégie de contenu : sujets, calendrier, cadres éditoriaux.

## Sources et licences

Ces skills sont open source ; leurs licences sont dans `LICENSES/`. Sélection AI Makers,
août 2026, depuis skills.sh :

- `coreyhaines31/marketingskills` (MIT) — github.com/coreyhaines31/marketingskills

---
aimakers.fr · Le Benchmark des Makers
